﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace _4.Clase_Producto
{
    internal class ClaseProducto
    {
        private string nombre, codigoBarras, precioUnitario;
        private float cantidad;
        private int categoria;

        public string Nombre { get => nombre; set => nombre = value; }
        public string PrecioUnitario { get => precioUnitario; set => precioUnitario = value; }
        public float Cantidad { get => cantidad; set => cantidad = value; }
        public string CodigoBarras { get => codigoBarras; set => codigoBarras = value; }
        public int Categoria { get => categoria; set => categoria = value; }

        public ClaseProducto()
        {

        }

        public ClaseProducto(string nombre, string precioUnitario, float cantidad, string codigoBarras, int categoria)
        {
            this.nombre = nombre;
            this.precioUnitario = precioUnitario;
            this.cantidad = cantidad;
            this.codigoBarras = codigoBarras;
            this.categoria = categoria;
        }

        public void CalcularTotal()
        {
            Console.WriteLine(-------------------);
            Console.WriteLine("Tu total es de :");
            Console.WriteLine(-------------------);
        }
        public void MostrarProducto()
        {
            Console.WriteLine("Nombre :{0}\tCodigo de barra :{1}\tPrecio Unitario :{2}\tCantidad :{3}\tCategotia :{4}",nombre,codigoBarras,precioUnitario,cantidad,categoria);

        }
        public void AplicarDescuento(float porcentaje)
        {
            Console.WriteLine("El descuento a aplicar sera de un 11%");
        }
        public void ActualizarCantidad(int nuevaCantidad)
        {
            Console.WriteLine("La cantidad es :");
        }
    }
}
