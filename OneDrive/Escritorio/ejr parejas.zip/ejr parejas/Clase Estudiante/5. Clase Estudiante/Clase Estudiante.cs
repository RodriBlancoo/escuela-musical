﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5.Clase_Estudiante
{
    internal class Clase_Estudiante
    {
        private string _id,nombre,materia,correoElectronico;
        private double notaFinal;

        public Clase_Estudiante()
        {
        }

        public Clase_Estudiante(string id, string nombre, string materia, string correoElectronico, double notaFinal)
        {
            Id = id;
            this.Nombre = nombre;
            this.Materia = materia;
            this.CorreoElectronico = correoElectronico;
            this.NotaFinal = notaFinal;
        }

        public string Id { get => _id; set => _id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Materia { get => materia; set => materia = value; }
        public string CorreoElectronico { get => correoElectronico; set => correoElectronico = value; }
        public double NotaFinal { get => notaFinal; set => notaFinal = value; }

        public void MostrarResultado()
        {

        }
        private void MostrarDatos()
        {
            Console.WriteLine("Nombre{0}\tMateria{1}\tNOta Final{2}\tID{3}",nombre,materia,NotaFinal,Id,correoElectronico);
        }
        private void ActualizarNotaFinal(double nuevaNota)
        {

        }  
        private void EnviarCorreo(string mensaje)
        {

        }
    }
}
