﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer_1_parejas
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero = 0;

            while (true)
            {
                Console.Write("Introduce un número (0 para salir): ");
                string entrada = Console.ReadLine();

                if (int.TryParse(entrada, out numero))
                {
                    if (numero == 0)
                    {
                        Console.WriteLine("Saliendo del programa...");
                        break;
                    }

                    if (numero > 0)
                    {
                        Console.WriteLine("El número es positivo.");
                    }
                    else
                    {
                        Console.WriteLine("El número es negativo.");
                    }
                }
                else
                {
                    Console.WriteLine("Por favor, introduce un número válido.");
                }
            }

        }
    }
}
