﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer_9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int tabla, i = 1, resp = 0;
            Console.WriteLine("Ingrese la tabla del multiplicar que deseas:\n");
            tabla = int.Parse(Console.ReadLine());
            Console.Clear();
            while (i <= 10)
            {
                resp = tabla * i;
                Console.WriteLine("\t{0}*{1}={2}", tabla, i, resp);
                i++;
            }

            Console.WriteLine("fin del programa");
            Console.ReadKey();
        }
    }
}
