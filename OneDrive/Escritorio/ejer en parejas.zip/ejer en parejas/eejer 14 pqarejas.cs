﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer_14
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero = 0; 
            int suma = 0;   

            Console.WriteLine("Ingresa números para sumarlos. Ingresa 0 para terminar.");

            do
            {
                Console.Write("Ingresa un número: ");
                numero = int.Parse(Console.ReadLine()); 
                suma += numero; 

            } while (numero != 0); 

            Console.WriteLine($"La suma total es: {suma}");

        }
    }
}
