﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer_10parejas
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Introduce un número:");
            int numero = int.Parse(Console.ReadLine());

            bool primo = true;
            int divisor = 2;

            while (divisor < numero)
            {
                if (numero % divisor == 0)
                {
                    primo = false;
                    break; 
                }
                divisor++; 
            }

            if (numero <= 1)
            {
                primo = false; 
            }

            if (primo)
            {
                Console.WriteLine($"{numero} es un número primo.");
            }
            else
            {
                Console.WriteLine($"{numero} no es un número primo.");
            }



        }
    }
}
