﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer_13_parejas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce el texto:");
            string texto = Console.ReadLine();

            Console.WriteLine("Introduce el carácter que deseas contar:");
            char caracter = Console.ReadLine()[0];

            int contador = 0;
            int indice = 0;

            while (indice < texto.Length)
            {
                if (texto[indice] == caracter)
                {
                    contador++;
                }
                indice++;
            }

            Console.WriteLine($"El carácter '{caracter}' aparece {contador}veces en el texto.");
        }
    }
}
