﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer_15_parejas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese el número hasta el cual desea calcular la serie de Fibonacci:");
            int n = int.Parse(Console.ReadLine());

            int a = 0; 
            int b = 1; 
            int contador = 0;

            Console.WriteLine("Serie de Fibonacci:");

            while (contador < n)
            {
                Console.WriteLine(a);

                int temp = a + b;
                a = b;
                b = temp;

                contador++;
            }

        }
    }
}
